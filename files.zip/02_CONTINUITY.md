# 02 — CONTINUITY: progress & project state

> Claude reads this at the start of every chat. After each lesson, replace `## CURRENT STATE` with the block from the CONTINUITY UPDATE, add the LESSON LOG row, and append the cheat-sheet lines.

## CURRENT STATE

**Last completed lesson:** none — fresh start
**Next lesson:** L01 — Start the project: Visual Studio 2026, .NET 10 & your first API
**Pace:** 4 lessons a day (~2 hours each, 9 days)
**Today:** Day 1 — L01, L02, L03, L04
**Behind schedule?** no

### Project state (CareRoute — hospital platform)
- **Last project step completed:** none
- **Physical location:** _fill in (e.g., `D:\CareRoute\`) — use a new folder, not the old L07 project_
- **Solution tree:** _(created in L01)_
- **What works:** nothing yet
- **Differences from the lessons / known issues:** none
- **HTTPS port:** _fill in after L01 (7xxx)_
- **GitHub repository URL:** _fill in after L01_

### Code facts (VERIFIED names and signatures — Claude must use these, never guess)
- _(empty — filled in from L01 on: namespaces, class names, method signatures, route templates, config keys, test helper names)_

### Azure resources (from L28)
| Resource | Name | Tier | Region | Running cost note |
|---|---|---|---|---|
| _(none yet)_ | | | | |

### Working agreements
1. Lessons are delivered complete (`START Lxx`) or part by part (`START Lxx PARTS`); five parts: Understand · Build · Test · Practice · Review; ~2 hours each.
2. **No TDD.** Build first, check by running; all tests in Part 3 at the end of the lesson. One test per rule, every boundary, a regression test per bug; once per lesson break a rule on purpose and watch its test go red.
3. **Clean Architecture:** Domain ← Application ← Infrastructure ← Api/Functions/Worker. Every new file names its layer.
4. **DDD only as 🧩 notes inside lessons** — no DDD lessons. `DDD <term>` for more.
5. Controllers only (no minimal-API endpoints). Bind DTOs, never entities.
6. Testing toolkit: xUnit · FluentAssertions **7.x** · NSubstitute (ports only) · Bogus (fixed seed) · Testcontainers (from L10) · bUnit (L22).
7. Logs: structured templates, IDs only, never names or national numbers; every response carries `X-Correlation-Id`.
8. Visual Studio menus over the terminal; Azure Portal over the CLI; every Azure lesson ends with cleanup.

### Project steps
- [ ] P01 First API · [ ] P02 Fundamentals · [ ] P03 Clean Architecture + test toolkit · [ ] P04 Domain I
- [ ] P05 Domain II · [ ] P06 Application layer · [ ] P07 SQL basics · [ ] P08 SQL for developers
- [ ] P09 EF Core · [ ] P10 EF Core + Testcontainers · [ ] P11 CQRS & events · [ ] P12 Observability
- [ ] P13 Blazor basics · [ ] P14 Blazor forms · [ ] P15 Security I · [ ] L16 Checkpoint 1
- [ ] P17 MongoDB Intake · [ ] P18 RabbitMQ · [ ] P19 Reliability & outbox · [ ] P20 Distributed tracing
- [ ] P21 Process manager · [ ] P22 Testing strategy & CI · [ ] P23 Production readiness · [ ] P24 Security II
- [ ] P25 Performance · [ ] P26 Resilience & ACL · [ ] L27 Checkpoint 2 · [ ] P28 App Service & Key Vault
- [ ] P29 Application Insights · [ ] P30 Service Bus · [ ] P31 Durable Functions · [ ] P32 Logic Apps
- [ ] P33 API Management · [ ] P34 Final checkpoint + capstone

### Ubiquitous language (source of truth: docs/ubiquitous-language.md)
- _(empty — starts in L03)_

### Environment
- Visual Studio 2026 version: _fill in_ · workloads: ASP.NET and web development, Azure development
- .NET SDK: _fill in (10.0.x)_
- SQL: LocalDB / full SQL Server _(circle)_
- Docker Desktop: installed? _yes/no_ (needed from L10)
- MongoDB Compass: _yes/no_ (needed from L17)
- Azure subscription: _type, fill in before L28_

### Checkpoint scores / Confidence
- Checkpoint 1 (L16): _?_ · Checkpoint 2 (L27): _?_ · Final (L34): _?_

### Weak spots (max 15)
- _(none yet)_

### Things that confused me
- _(your own words)_

### Skipped / deferred items
- _(none)_

### Decisions (ADRs, one line each)
- _(none yet — ADR-001 Clean Architecture comes in L03)_

### "Explain CareRoute in 3 minutes" versions
- _(starts after L06)_

## LESSON LOG
| Lesson | Date | Time spent | Key takeaways (short) | Self-score (avg /5) | Open questions |
|---|---|---|---|---|---|

---

## KEY IDEAS CHEAT SHEET
_(Grows by 3–6 lines per lesson, including at least one trade-off and one failure mode. L34 condenses it to one printable page.)_

- .NET 10 is the current LTS (November 2025 → November 2028); C# 14, ASP.NET Core 10 and EF Core 10 ship with it.
- Licences shape choices: MediatR pinned to 12.5.0 and FluentAssertions to 7.x (both Apache 2.0); MediatR 13+, FluentAssertions 8+, MassTransit 9+ and AutoMapper 15+ are commercial.
- Clean Architecture: dependencies point inward; the Domain references nothing; infrastructure is swappable behind ports.
- Tests come at the end of each lesson — named after the rule, never after the implementation — and one is broken on purpose to prove it can fail.
- For every technology, be ready to say what it costs and how it fails — not only what it does.
